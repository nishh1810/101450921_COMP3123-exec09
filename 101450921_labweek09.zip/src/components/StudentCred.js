import React from 'react'

export default function StudentCred (props) {
  return (
   <>
   <h3>{props.studentID}</h3>
   <h4>{props.name}</h4>
   <h5>George Brown College</h5>
   </>
  )
}
