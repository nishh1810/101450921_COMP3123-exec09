import React from 'react'

export default function SmallHead() {
  return (
    <>
    <h2>React JS Programming Week09 Lab Exercise </h2>

    </>
  )
}
