import React from 'react';

export default function MyHeading() { // Changed function name to MyHeading
  return (
    <div>
      <h1>Welcome to FullStack Development -1</h1>
      
    </div>
  );
}
